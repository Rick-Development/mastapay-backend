<?php

namespace App\Http\Helpers\Payscribe;

use App\Http\Helpers\ConnectionHelper;

class PayscribePayoutHelper extends ConnectionHelper{

    public function __construct(){
        parent::__construct();
    }

    /**
     * Retrieves a list of banks available for payouts.
     *
     * @return array An array of bank details including bank code, name, and other relevant information.
     */
    public function getPayoutBankList(){
        $url = '/payouts/bank/list';
        $this->get($url);
    }

    public function validateAccountBeforeInitiatingTransfer($data){
        $url = '/payouts/account/lookup';
        $data = [
            "account" => "7038067493",
            "bank" => "100004"
        ];
        $this->post($url,$data);
    }

    public function getPayoutsFee($amount){
        $url  = "/payouts/fee/?amount=$amount&currency=ngn";
        $this->get($url);
    }

    
    public function transfer($data){
            $url = "/payouts/transfer";
            $randomUUID = rand(0,20);
            $data = [
                    "amount" => "100",
                    "bank" => "058",
                    "account" => "0151820365",
                    "currency" => "ngn",
                    "narration" => "School fee",
                    "ref" => "$randomUUID"
            ];
            $this->post($url,$data);
    }

    public function verifyTransfer($transactionID){
        $url = "/payouts/verify/$transactionID";
        $this->get($url);
    }

    
}

