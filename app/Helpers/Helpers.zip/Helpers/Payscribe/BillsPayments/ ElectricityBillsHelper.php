<?php
namespace App\Http\Helpers\Payscribe\BillsPayments;

use App\Http\Helpers\ConnectionHelper;


class  ElectricityBillsHelper extends ConnectionHelper {


    public function __construct(){
        parent::__construct();
    }
    public function validateElectricity($data){
        $url = "/electricity/validate";
        $data= [
            "meter_number" => "54150143102",
            "meter_type"  => "prepaid",
            "amount"  => "1000",
            "service"  => "ikedc"
        ];
        $this->post($url,$data);

    }

    public function payElectricity(){
        $url = "/electricity/vend";
        $data= [
            "meter_number" => "54150143102",
            "meter_type"  => "prepaid",
            "amount"  => 100,
            "service"  => "ikedc",
            "phone"  => "07038067493",
            "customer_name"  => "26, Terrance Connelly",
            "ref" => "3a34de42-d4dc-42c1-904a-c28c6002cb8b"
        ];

        $this->post($url,$data);
    }

    #GET
     public function requeryTransaction($transactioID){
        $url = "https://sandbox.payscribe.ng/api/v1/requery/?trans_id=$transactioID";
        $this->get( $url);

     }
     
}