<?php
namespace App\Http\Helpers\Payscribe\BillsPayments;

use App\Http\Helpers\ConnectionHelper;

class DataBundleHelper extends ConnectionHelper{

    public function __construct(){
        parent::__construct();
    }
    public function dataLookup($network){
        $url = "/data/lookup?network=$network";
        $this->get($url);

    }

    public function dataVending($data){
        $url = "/data/vend";
        $data = [
        "plan" => "PSPLAN_177",
        "recipient" => "08132931751",
        "network" => "mtn",
        "ref" => "59df6d36-6649-4107-96ea-20b3a9b460a3"
        ];
        $this->post($url,$data);

    }

}