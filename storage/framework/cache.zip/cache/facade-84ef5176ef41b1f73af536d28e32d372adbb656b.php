<?php

namespace Facades\XContains\XContains\Cri;

use Illuminate\Support\Facades\Facade;

/**
 * @see \XContains\XContains\Cri\AL
 */
class AL extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'XContains\XContains\Cri\AL';
    }
}
