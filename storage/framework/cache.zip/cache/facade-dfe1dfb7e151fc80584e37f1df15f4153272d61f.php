<?php

namespace Facades\XContains\XContains\Rec;

use Illuminate\Support\Facades\Facade;

/**
 * @see \XContains\XContains\Rec\DIG
 */
class DIG extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'XContains\XContains\Rec\DIG';
    }
}
