<?php

namespace Facades\XContains\XContains\Ars;

use Illuminate\Support\Facades\Facade;

/**
 * @see \XContains\XContains\Ars\Ai
 */
class Ai extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'XContains\XContains\Ars\Ai';
    }
}
